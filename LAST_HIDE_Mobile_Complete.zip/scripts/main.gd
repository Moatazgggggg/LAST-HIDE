extends Node3D

const PLAYER_SCRIPT = preload("res://scripts/player.gd")
const PORT := 24567
const MAX_PLAYERS := 3

var players: Dictionary = {}
var monster_peer_id := 1
var status_label: Label
var ip_input: LineEdit
var menu: Control
var world_root: Node3D
var started := false

func _ready() -> void:
    _make_world()
    _make_menu()
    multiplayer.peer_connected.connect(_on_peer_connected)
    multiplayer.peer_disconnected.connect(_on_peer_disconnected)
    multiplayer.connected_to_server.connect(func(): _status("اتصلت بالغرفة. مستني اكتمال اللاعبين."))
    multiplayer.connection_failed.connect(func(): _status("فشل الاتصال. راجع عنوان IP ونقطة الاتصال."))
    multiplayer.server_disconnected.connect(func(): _status("صاحب الغرفة خرج من اللعبة."))

func _make_world() -> void:
    var env_node := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.012, 0.018, 0.026)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.38, 0.40, 0.48)
    env.ambient_light_energy = 0.65
    env_node.environment = env
    add_child(env_node)

    var moon := DirectionalLight3D.new()
    moon.rotation_degrees = Vector3(-48, -25, 0)
    moon.light_energy = 0.42
    add_child(moon)

    world_root = Node3D.new()
    world_root.name = "World"
    add_child(world_root)

    _box("Ground", Vector3(0,-0.5,0), Vector3(44,1,44), Color(0.075,0.085,0.09))
    _box("NorthWall", Vector3(0,2,-21), Vector3(44,4,1), Color(0.16,0.17,0.18))
    _box("SouthWall", Vector3(0,2,21), Vector3(44,4,1), Color(0.16,0.17,0.18))
    _box("WestWall", Vector3(-21,2,0), Vector3(1,4,44), Color(0.16,0.17,0.18))
    _box("EastWall", Vector3(21,2,0), Vector3(1,4,44), Color(0.16,0.17,0.18))
    # تقسيمات داخلية مع ممرات مفتوحة
    _box("InnerA", Vector3(-9,1.5,-5), Vector3(0.7,3,19), Color(0.19,0.18,0.17))
    _box("InnerB", Vector3(9,1.5,5), Vector3(0.7,3,19), Color(0.19,0.18,0.17))
    _box("BackRoom", Vector3(0,1.5,-12), Vector3(16,3,0.7), Color(0.19,0.18,0.17))
    _box("CenterDivider", Vector3(0,1.5,1), Vector3(12,3,0.7), Color(0.15,0.16,0.18))
    # مخابئ وصناديق
    for p in [Vector3(-15,0.9,-14),Vector3(15,0.9,-14),Vector3(-15,0.9,14),Vector3(15,0.9,14),Vector3(0,0.9,16),Vector3(-5,0.9,-7),Vector3(5,0.9,7)]:
        _box("HideCrate", p, Vector3(2.2,1.8,2.2), Color(0.22,0.17,0.12))
    for p in [Vector3(-5,1.25,9),Vector3(5,1.25,-9),Vector3(13,1.25,4)]:
        _box("Locker", p, Vector3(1.25,2.5,1.25), Color(0.075,0.12,0.14))

func _box(n: String, pos: Vector3, size: Vector3, color: Color) -> void:
    var body := StaticBody3D.new()
    body.name = n
    body.position = pos
    var mesh_instance := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    mesh_instance.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.95
    mesh_instance.material_override = mat
    body.add_child(mesh_instance)
    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = size
    collision.shape = shape
    body.add_child(collision)
    world_root.add_child(body)

func _make_menu() -> void:
    menu = Control.new()
    menu.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(menu)
    var panel := PanelContainer.new()
    panel.set_anchors_preset(Control.PRESET_CENTER)
    panel.position = Vector2(-250,-205)
    panel.size = Vector2(500,410)
    menu.add_child(panel)
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 13)
    panel.add_child(col)

    var title := Label.new()
    title.text = "LAST HIDE"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 38)
    col.add_child(title)
    var sub := Label.new()
    sub.text = "آخر مخبأ | رعب واستغماية لثلاثة أصدقاء"
    sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    col.add_child(sub)

    ip_input = LineEdit.new()
    ip_input.placeholder_text = "IP صاحب نقطة الاتصال"
    ip_input.text = "192.168.43.1"
    col.add_child(ip_input)

    var host := Button.new()
    host.text = "إنشاء غرفة — هتلعب الوحش"
    host.custom_minimum_size.y = 54
    host.pressed.connect(_host)
    col.add_child(host)

    var join := Button.new()
    join.text = "انضمام للغرفة"
    join.custom_minimum_size.y = 54
    join.pressed.connect(_join)
    col.add_child(join)

    status_label = Label.new()
    status_label.text = "شغّل نقطة الاتصال على موبايل واحد، ووصل الموبايلات الثلاثة عليها."
    status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    col.add_child(status_label)

func _host() -> void:
    var peer := ENetMultiplayerPeer.new()
    var err := peer.create_server(PORT, MAX_PLAYERS - 1)
    if err != OK:
        _status("مش قادر أفتح الغرفة. اقفل أي جلسة قديمة وجرب تاني.")
        return
    multiplayer.multiplayer_peer = peer
    monster_peer_id = multiplayer.get_unique_id()
    _status("الغرفة اتفتحت. ابعت IP الموبايل ده لصاحبيك.")
    _lobby_count()

func _join() -> void:
    var peer := ENetMultiplayerPeer.new()
    var err := peer.create_client(ip_input.text.strip_edges(), PORT)
    if err != OK:
        _status("راجع عنوان IP.")
        return
    multiplayer.multiplayer_peer = peer
    _status("جاري الاتصال...")

func _on_peer_connected(_id: int) -> void:
    if multiplayer.is_server():
        _lobby_count()

func _on_peer_disconnected(_id: int) -> void:
    _status("لاعب خرج. محتاجين 3 لاعبين لبدء الجولة.")
    if multiplayer.is_server():
        _lobby_count()

func _lobby_count() -> void:
    var count := multiplayer.get_peers().size() + 1
    _status("اللاعبين: %d / 3" % count)
    if count == 3 and not started:
        _begin_round.rpc()

@rpc("authority","call_local","reliable")
func _begin_round() -> void:
    if started: return
    started = true
    menu.hide()
    var ids: Array[int] = [1]
    for id in multiplayer.get_peers():
        ids.append(id)
    ids.sort()
    for i in range(ids.size()):
        var role := "monster" if ids[i] == monster_peer_id else "hider"
        _create_player.rpc(ids[i], role, i)

@rpc("authority","call_local","reliable")
func _create_player(id: int, role: String, slot: int) -> void:
    if players.has(id): return
    var actor := CharacterBody3D.new()
    actor.name = "Player_%d" % id
    actor.set_script(PLAYER_SCRIPT)
    add_child(actor)
    actor.configure(id, role, slot)
    players[id] = actor

func _status(msg: String) -> void:
    if is_instance_valid(status_label):
        status_label.text = msg
