extends CharacterBody3D

const HIDER_SPEED := 4.6
const MONSTER_SPEED := 5.4
const ACCEL := 18.0
const DECEL := 22.0
const GRAVITY := 18.0
const JUMP_SPEED := 5.0

var peer_id := 1
var role := "hider"
var is_local := false
var camera: Camera3D
var head: Node3D
var body_mesh: MeshInstance3D
var joystick: Control
var look_area: Control
var jump_button: Button
var crouch_button: Button
var move_vector := Vector2.ZERO
var look_finger := -1
var move_finger := -1
var last_look := Vector2.ZERO
var yaw := 0.0
var pitch := 0.0
var last_sync := 0.0
var idle_seconds := 0.0
var has_warned := false
var ui_layer: CanvasLayer
var status_text: Label
var settings_panel: PanelContainer
var sensitivity := 0.18
var quality := "متوسط"

func configure(id: int, player_role: String, slot: int) -> void:
    peer_id = id
    role = player_role
    is_local = id == multiplayer.get_unique_id()
    set_multiplayer_authority(id)
    var starts := [Vector3(-4,0.1,5),Vector3(4,0.1,5),Vector3(0,0.1,-5)]
    position = starts[slot % starts.size()]
    _build_actor()

func _ready() -> void:
    if is_local:
        camera.current = true
        _build_mobile_ui()
    else:
        camera.current = false

func _build_actor() -> void:
    var collision := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.38 if role == "hider" else 0.68
    capsule.height = 1.8 if role == "hider" else 3.0
    collision.shape = capsule
    collision.position.y = capsule.height * 0.5
    add_child(collision)

    body_mesh = MeshInstance3D.new()
    var mesh := CapsuleMesh.new()
    mesh.radius = 0.38 if role == "hider" else 0.68
    mesh.height = 1.8 if role == "hider" else 3.0
    body_mesh.mesh = mesh
    body_mesh.position.y = mesh.height * 0.5
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.40,0.025,0.035) if role == "monster" else Color(0.16,0.28,0.34)
    mat.roughness = 0.82
    body_mesh.material_override = mat
    add_child(body_mesh)

    head = Node3D.new()
    head.position.y = 1.62 if role == "hider" else 2.65
    add_child(head)
    camera = Camera3D.new()
    camera.fov = 82
    head.add_child(camera)

    var name_tag := Label3D.new()
    name_tag.text = "الوحش" if role == "monster" else "مختبئ"
    name_tag.position.y = 3.5 if role == "monster" else 2.15
    name_tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    name_tag.font_size = 28
    add_child(name_tag)

func _build_mobile_ui() -> void:
    ui_layer = CanvasLayer.new()
    add_child(ui_layer)
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_PASS
    ui_layer.add_child(root)

    # منطقة النظر: النصف الأيمن من الشاشة، مع تجاهل أزرار الواجهة.
    look_area = Control.new()
    look_area.anchor_left = 0.42
    look_area.anchor_right = 1.0
    look_area.anchor_top = 0.0
    look_area.anchor_bottom = 1.0
    look_area.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(look_area)

    joystick = Control.new()
    joystick.position = Vector2(48, -205)
    joystick.anchor_left = 0.0
    joystick.anchor_top = 1.0
    joystick.anchor_right = 0.0
    joystick.anchor_bottom = 1.0
    joystick.custom_minimum_size = Vector2(170,170)
    joystick.mouse_filter = Control.MOUSE_FILTER_STOP
    root.add_child(joystick)
    joystick.draw.connect(_draw_joystick)
    joystick.gui_input.connect(_on_joystick_input)

    jump_button = _make_button(root, "قفز", Vector2(-155,-170), Vector2(112,64))
    jump_button.pressed.connect(_jump)
    crouch_button = _make_button(root, "انحناء", Vector2(-155,-92), Vector2(112,64))
    crouch_button.pressed.connect(_toggle_crouch)

    var settings := _make_button(root, "⚙", Vector2(-72,20), Vector2(58,58))
    settings.anchor_left = 1
    settings.anchor_right = 1
    settings.anchor_top = 0
    settings.anchor_bottom = 0
    settings.pressed.connect(_toggle_settings)

    status_text = Label.new()
    status_text.text = "الوحش" if role == "monster" else "اهرب واستخبى!"
    status_text.anchor_left = 0.5
    status_text.anchor_right = 0.5
    status_text.offset_left = -120
    status_text.offset_right = 120
    status_text.offset_top = 20
    status_text.add_theme_font_size_override("font_size", 22)
    status_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    root.add_child(status_text)

    var crosshair := Label.new()
    crosshair.text = "+"
    crosshair.anchor_left = 0.5
    crosshair.anchor_top = 0.5
    crosshair.anchor_right = 0.5
    crosshair.anchor_bottom = 0.5
    crosshair.offset_left = -8
    crosshair.offset_right = 8
    crosshair.offset_top = -15
    crosshair.offset_bottom = 15
    crosshair.add_theme_font_size_override("font_size", 25)
    root.add_child(crosshair)

func _make_button(parent: Control, txt: String, pos: Vector2, size: Vector2) -> Button:
    var b := Button.new()
    b.text = txt
    b.position = pos
    b.size = size
    b.anchor_left = 1.0
    b.anchor_right = 1.0
    b.anchor_top = 1.0
    b.anchor_bottom = 1.0
    b.add_theme_font_size_override("font_size", 19)
    parent.add_child(b)
    return b

func _draw_joystick() -> void:
    var center := joystick.size * 0.5
    joystick.draw_circle(center, 72, Color(0.04,0.05,0.06,0.42))
    joystick.draw_arc(center, 72, 0, TAU, 48, Color(0.8,0.82,0.86,0.7), 3.0)
    joystick.draw_circle(center + move_vector * 48, 27, Color(0.78,0.80,0.84,0.72))

func _on_joystick_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            move_finger = event.index
            _set_joystick(event.position)
        elif event.index == move_finger:
            move_finger = -1
            move_vector = Vector2.ZERO
            joystick.queue_redraw()
    elif event is InputEventScreenDrag and event.index == move_finger:
        _set_joystick(event.position)

func _set_joystick(local_pos: Vector2) -> void:
    var center := joystick.size * 0.5
    move_vector = ((local_pos - center) / 62.0).limit_length(1.0)
    joystick.queue_redraw()

func _input(event: InputEvent) -> void:
    if not is_local: return
    if event is InputEventScreenTouch:
        if event.pressed and event.position.x > get_viewport().get_visible_rect().size.x * 0.42:
            look_finger = event.index
            last_look = event.position
        elif not event.pressed and event.index == look_finger:
            look_finger = -1
    elif event is InputEventScreenDrag and event.index == look_finger:
        var delta_pos := event.position - last_look
        last_look = event.position
        _rotate_view(delta_pos)
    elif event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        _rotate_view(event.relative)
    elif event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _rotate_view(delta_pos: Vector2) -> void:
    yaw -= delta_pos.x * sensitivity * 0.01
    pitch = clamp(pitch - delta_pos.y * sensitivity * 0.01, -1.25, 1.25)
    rotation.y = yaw
    head.rotation.x = pitch

func _physics_process(delta: float) -> void:
    if is_local:
        _move_local(delta)
        last_sync += delta
        if last_sync >= 0.06:
            last_sync = 0.0
            _send_state.rpc(position, rotation.y, head.rotation.x)
        if role == "hider":
            if move_vector.length() < 0.08:
                idle_seconds += delta
                if idle_seconds >= 15.0 and not has_warned:
                    has_warned = true
                    if is_instance_valid(status_text):
                        status_text.text = "I'M HERE!"
            else:
                idle_seconds = 0.0
                has_warned = false
    else:
        pass

func _move_local(delta: float) -> void:
    if not is_on_floor():
        velocity.y -= GRAVITY * delta
    var keyboard := Vector2(
        Input.get_action_strength("move_right") - Input.get_action_strength("move_left"),
        Input.get_action_strength("move_back") - Input.get_action_strength("move_forward")
    )
    var input_dir := move_vector if move_vector.length() > 0.05 else keyboard
    input_dir = input_dir.limit_length(1.0)
    var direction := (transform.basis * Vector3(input_dir.x,0,input_dir.y)).normalized()
    var speed := MONSTER_SPEED if role == "monster" else HIDER_SPEED
    var target_x := direction.x * speed
    var target_z := direction.z * speed
    velocity.x = move_toward(velocity.x, target_x, (ACCEL if direction else DECEL) * delta)
    velocity.z = move_toward(velocity.z, target_z, (ACCEL if direction else DECEL) * delta)
    if Input.is_action_just_pressed("ui_accept") and is_on_floor():
        velocity.y = JUMP_SPEED
    move_and_slide()

func _jump() -> void:
    if is_on_floor():
        velocity.y = JUMP_SPEED

func _toggle_crouch() -> void:
    var crouched := crouch_button.text == "انحناء"
    crouch_button.text = "وقوف" if crouched else "انحناء"
    var target := 1.15 if crouched else 1.62
    head.position.y = target
    camera.fov = 76 if crouched else 82

func _toggle_settings() -> void:
    if is_instance_valid(settings_panel):
        settings_panel.queue_free()
        settings_panel = null
        return
    settings_panel = PanelContainer.new()
    settings_panel.position = Vector2(20,20)
    settings_panel.size = Vector2(300,260)
    ui_layer.add_child(settings_panel)
    var col := VBoxContainer.new()
    settings_panel.add_child(col)
    var title := Label.new()
    title.text = "إعدادات التحكم والجرافيك"
    col.add_child(title)
    var sens_label := Label.new()
    sens_label.text = "حساسية النظر"
    col.add_child(sens_label)
    var slider := HSlider.new()
    slider.min_value = 0.08
    slider.max_value = 0.40
    slider.step = 0.01
    slider.value = sensitivity
    slider.value_changed.connect(func(v): sensitivity = v)
    col.add_child(slider)
    var quality_pick := OptionButton.new()
    for q in ["قليل","متوسط","عالي","اكستريم"]:
        quality_pick.add_item(q)
    quality_pick.selected = 1
    quality_pick.item_selected.connect(_set_quality)
    col.add_child(quality_pick)
    var close := Button.new()
    close.text = "إغلاق"
    close.pressed.connect(func(): settings_panel.queue_free(); settings_panel = null)
    col.add_child(close)

func _set_quality(index: int) -> void:
    var options := ["قليل","متوسط","عالي","اكستريم"]
    quality = options[index]
    var scale := [0.65,0.8,1.0,1.25][index]
    camera.fov = 82 / scale
    # إعدادات الإضاءة والخامات بسيطة لتناسب الأجهزة المتوسطة.
    get_viewport().scaling_3d_scale = clamp(scale,0.65,1.0)

@rpc("authority","call_remote","unreliable")
func _send_state(pos: Vector3, rot_y: float, rot_x: float) -> void:
    if is_local: return
    position = position.lerp(pos,0.72)
    rotation.y = rot_y
    head.rotation.x = rot_x
